#ifndef GLOBALS_H
#define GLOBALS_H

#include "Structs.h"

extern Budget budgets[600];
extern int budgetCount;
extern int nextBudgetId;

extern Request requests[200];
extern int requestCount;
extern int nextRequestId;

extern Account accounts[200];
extern int accountCount;

extern Profile profiles[200];
extern int profileCount;

#endif
