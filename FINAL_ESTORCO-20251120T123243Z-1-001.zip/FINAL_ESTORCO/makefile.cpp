#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;

void saveBudgetsToFile() {
    ofstream f("budgets.txt");
    if (!f) return;
    for (int i = 0; i < budgetCount; ++i) {
        f << budgets[i].id << "," << budgets[i].name << "," << fixed << setprecision(2) << budgets[i].amount << "," << budgets[i].type << "," << budgets[i].owner << "\n";
    }
    f.close();
}

void loadBudgetsFromFile() {
    ifstream f("budgets.txt");
    if (!f) return;
    budgetCount = 0;
    nextBudgetId = 1;
    string line;
    while (getline(f, line) && budgetCount < MAX_BUDGETS) {
        if (line.empty()) continue;
        size_t p1 = line.find(',');
        if (p1 == string::npos) continue;
        size_t p2 = line.find(',', p1 + 1);
        if (p2 == string::npos) continue;
        size_t p3 = line.find(',', p2 + 1);
        if (p3 == string::npos) continue;
        size_t p4 = line.find(',', p3 + 1);
        if (p4 == string::npos) continue;
        Budget b;
        try {
            b.id = stoi(line.substr(0, p1));
            b.name = line.substr(p1 + 1, p2 - p1 - 1);
            b.amount = stod(line.substr(p2 + 1, p3 - p2 - 1));
            b.type = line.substr(p3 + 1, p4 - p3 - 1);
            b.owner = line.substr(p4 + 1);
            budgets[budgetCount++] = b;
            if (b.id >= nextBudgetId) nextBudgetId = b.id + 1;
        } catch (...) {
            continue;
        }
    }
    f.close();
}

void saveRequestsToFile() {
    ofstream f("requests.txt");
    if (!f) return;
    for (int i = 0; i < requestCount; ++i) {
        f << requests[i].id << "," << requests[i].childUsername << "," << requests[i].childName << "," << requests[i].purpose << "," << fixed << setprecision(2) << requests[i].amount << "," << requests[i].status << "\n";
    }
    f.close();
}

void loadRequestsFromFile() {
    ifstream f("requests.txt");
    if (!f) return;
    requestCount = 0;
    nextRequestId = 1;
    string line;
    while (getline(f, line) && requestCount < MAX_REQUESTS) {
        if (line.empty()) continue;
        size_t p1 = line.find(',');
        size_t p2 = (p1==string::npos)?string::npos:line.find(',', p1 + 1);
        size_t p3 = (p2==string::npos)?string::npos:line.find(',', p2 + 1);
        size_t p4 = (p3==string::npos)?string::npos:line.find(',', p3 + 1);
        size_t p5 = (p4==string::npos)?string::npos:line.find(',', p4 + 1);
        if (p1==string::npos || p2==string::npos || p3==string::npos || p4==string::npos || p5==string::npos) continue;
        Request r;
        try {
            r.id = stoi(line.substr(0, p1));
            r.childUsername = line.substr(p1 + 1, p2 - p1 - 1);
            r.childName = line.substr(p2 + 1, p3 - p2 - 1);
            r.purpose = line.substr(p3 + 1, p4 - p3 - 1);
            r.amount = stod(line.substr(p4 + 1, p5 - p4 - 1));
            r.status = line.substr(p5 + 1);
            requests[requestCount++] = r;
            if (r.id >= nextRequestId) nextRequestId = r.id + 1;
        } catch (...) {
            continue;
        }
    }
    f.close();
}

void saveAccountsToFile() {
    ofstream f("accounts.txt");
    if (!f) return;
    for (int i = 0; i < accountCount; ++i) {
        f << accounts[i].username << "," << accounts[i].password << "," << accounts[i].role << "," << accounts[i].age << "\n";
    }
    f.close();
}

void loadAccountsFromFile() {
    ifstream f("accounts.txt");
    if (!f) return;
    accountCount = 0;
    string line;
    while (getline(f, line) && accountCount < MAX_ACCOUNTS) {
        if (line.empty()) continue;
        size_t p1 = line.find(',');
        size_t p2 = (p1==string::npos)?string::npos:line.find(',', p1 + 1);
        size_t p3 = (p2==string::npos)?string::npos:line.find(',', p2 + 1);
        if (p1==string::npos || p2==string::npos || p3==string::npos) continue;
        Account a;
        try {
            a.username = line.substr(0, p1);
            a.password = line.substr(p1 + 1, p2 - p1 - 1);
            a.role = line.substr(p2 + 1, p3 - p2 - 1);
            a.age = stoi(line.substr(p3 + 1));
            accounts[accountCount++] = a;
        } catch (...) {
            continue;
        }
    }
    f.close();
}

void saveProfilesToFile() {
    ofstream f("profiles.txt");
    if (!f) return;
    for (int i = 0; i < profileCount; ++i) {
        f << profiles[i].username << "," << profiles[i].displayName << "," << profiles[i].age << "," << fixed << setprecision(2) << profiles[i].allowance << "\n";
    }
    f.close();
}

void loadProfilesFromFile() {
    ifstream f("profiles.txt");
    if (!f) return;
    profileCount = 0;
    string line;
    while (getline(f, line) && profileCount < MAX_PROFILES) {
        if (line.empty()) continue;
        size_t p1 = line.find(',');
        size_t p2 = (p1==string::npos)?string::npos:line.find(',', p1 + 1);
        size_t p3 = (p2==string::npos)?string::npos:line.find(',', p2 + 1);
        if (p1==string::npos || p2==string::npos || p3==string::npos) continue;
        Profile p;
        try {
            p.username = line.substr(0, p1);
            p.displayName = line.substr(p1 + 1, p2 - p1 - 1);
            p.age = stoi(line.substr(p2 + 1, p3 - p2 - 1));
            p.allowance = stod(line.substr(p3 + 1));
            profiles[profileCount++] = p;
        } catch (...) {
            continue;
        }
    }
    f.close();
}

