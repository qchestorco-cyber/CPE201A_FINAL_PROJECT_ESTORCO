#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;

void createAccount() {
    if (accountCount >= MAX_ACCOUNTS) { cout << "Account storage full.\n"; return; }
    Account a;
    cout << "Enter username: ";
    getline(cin, a.username);
    while (a.username.empty()) { cout << "Username cannot be empty. Try again: "; getline(cin, a.username); }
    bool exists = false;
    for (int i = 0; i < accountCount; ++i) if (toLowerStr(accounts[i].username) == toLowerStr(a.username)) { exists = true; break; }
    if (exists) { cout << "Username exists. Aborting.\n"; return; }
    cout << "Enter password: ";
    getline(cin, a.password);
    cout << "Enter role (Parent/Child): ";
    getline(cin, a.role);
    while (toLowerStr(a.role) != "parent" && toLowerStr(a.role) != "child") { cout << "Role must be Parent or Child. Enter role: "; getline(cin, a.role); }
    a.age = getIntInput("Enter age: ");
    accounts[accountCount++] = a;
    saveAccountsToFile();
    if (toLowerStr(a.role) == "child") {
        if (profileCount >= MAX_PROFILES) { cout << "Profile storage full.\n"; return; }
        Profile p;
        p.username = a.username;
        cout << "Enter display name for child: ";
        getline(cin, p.displayName);
        if (p.displayName.empty()) p.displayName = a.username;
        p.age = a.age;
        p.allowance = 0.0;
        profiles[profileCount++] = p;
        saveProfilesToFile();
    }
    cout << "Account created.\n";
}

Account* loginAccount() {
    cout << "Enter username: ";
    string user;
    getline(cin, user);
    cout << "Enter password: ";
    string pass;
    getline(cin, pass);
    for (int i = 0; i < accountCount; ++i) if (accounts[i].username == user && accounts[i].password == pass) return &accounts[i];
    cout << "Invalid credentials.\n";
    return nullptr;
}

Profile* findProfileByUsername(const string &uname) {
    for (int i = 0; i < profileCount; ++i) if (toLowerStr(profiles[i].username) == toLowerStr(uname)) return &profiles[i];
    return nullptr;
}

void submitRequest(const Account &acc) {
    if (toLowerStr(acc.role) != "child") { cout << "Only child accounts can submit requests.\n"; return; }
    if (requestCount >= MAX_REQUESTS) { cout << "Request storage full.\n"; return; }
    Request r;
    r.id = nextRequestId++;
    r.childUsername = acc.username;
    Profile* p = findProfileByUsername(acc.username);
    if (p) r.childName = p->displayName;
    else { cout << "Enter child display name: "; getline(cin, r.childName); if (r.childName.empty()) r.childName = acc.username; }
    cout << "Enter purpose: ";
    getline(cin, r.purpose);
    r.amount = getDoubleInput("Enter requested amount: ");
    r.status = "Pending";
    requests[requestCount++] = r;
    saveRequestsToFile();
    cout << "Request submitted.\n";
}

