#ifndef STRUCTS_H
#define STRUCTS_H
#include <string>
#include "Funcs.h"
using namespace std;

const int MAX_BUDGETS = 600;
const int MAX_REQUESTS = 200;
const int MAX_ACCOUNTS = 200;
const int MAX_PROFILES = 200;

struct Budget {
    int id;
    string name;
    double amount;
    string type;
    string owner;
};

struct Request {
    int id;
    string childUsername;
    string childName;
    string purpose;
    double amount;
    string status;
};

struct Account {
    string username;
    string password;
    string role;
    int age;
};

struct Profile {
    string username;
    string displayName;
    int age;
    double allowance;
};

#endif
