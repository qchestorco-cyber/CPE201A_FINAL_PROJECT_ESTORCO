#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;

void sortBudgetsMenu() {
    cout << "Sort by: 1) Amount desc 2) Amount asc 3) Name asc 4) Name desc 5) Type then amount\n";
    int ch = getIntInput("Choice: ");
    if (budgetCount <= 1) { cout << "Not enough records to sort.\n"; return; }
    if (ch == 1) {
        sort(budgets, budgets + budgetCount, [](const Budget &a, const Budget &b){ return a.amount > b.amount; });
    } else if (ch == 2) {
        sort(budgets, budgets + budgetCount, [](const Budget &a, const Budget &b){ return a.amount < b.amount; });
    } else if (ch == 3) {
        sort(budgets, budgets + budgetCount, [](const Budget &a, const Budget &b){ return toLowerStr(a.name) < toLowerStr(b.name); });
    } else if (ch == 4) {
        sort(budgets, budgets + budgetCount, [](const Budget &a, const Budget &b){ return toLowerStr(a.name) > toLowerStr(b.name); });
    } else if (ch == 5) {
        sort(budgets, budgets + budgetCount, [](const Budget &a, const Budget &b){
            if (toLowerStr(a.type) != toLowerStr(b.type)) return toLowerStr(a.type) < toLowerStr(b.type);
            return a.amount > b.amount;
        });
    } else { cout << "Invalid choice.\n"; return; }
    saveBudgetsToFile();
    cout << "Sorted and saved.\n";
}

void showSummary() {
    double income = computeTotalIncome();
    double expense = computeTotalExpense();
    double balance = income - expense;
    int incCount = 0, expCount = 0;
    double avgInc = 0.0, avgExp = 0.0;
    double maxInc = -1.0, maxExp = -1.0;
    string maxIncName, maxExpName;
    for (int i = 0; i < budgetCount; ++i) {
        if (toLowerStr(budgets[i].type) == "income") {
            ++incCount;
            avgInc += budgets[i].amount;
            if (budgets[i].amount > maxInc) { maxInc = budgets[i].amount; maxIncName = budgets[i].name; }
        } else {
            ++expCount;
            avgExp += budgets[i].amount;
            if (budgets[i].amount > maxExp) { maxExp = budgets[i].amount; maxExpName = budgets[i].name; }
        }
    }
    if (incCount) avgInc /= incCount;
    if (expCount) avgExp /= expCount;
    int pending = 0;
    for (int i = 0; i < requestCount; ++i) if (toLowerStr(requests[i].status) == "pending") ++pending;
    drawHeaderBox("SUMMARY REPORT");
    cout << "Total Income    : " << fixed << setprecision(2) << income << "\n";
    cout << "Total Expense   : " << fixed << setprecision(2) << expense << "\n";
    cout << "Balance         : " << fixed << setprecision(2) << balance << "\n\n";
    cout << "Income Count    : " << incCount << "   Avg Income  : " << fixed << setprecision(2) << avgInc << "\n";
    cout << "Expense Count   : " << expCount << "   Avg Expense : " << fixed << setprecision(2) << avgExp << "\n\n";
    if (maxInc >= 0) cout << "Largest Income  : " << maxIncName << " (" << fixed << setprecision(2) << maxInc << ")\n";
    if (maxExp >= 0) cout << "Largest Expense : " << maxExpName << " (" << fixed << setprecision(2) << maxExp << ")\n";
    cout << "\nPending Requests: " << pending << " / " << requestCount << "\n";
    cout << "Profiles        : " << profileCount << "   Accounts: " << accountCount << "\n";
    cout << "+" << string(60, '=') << "+\n";
}

